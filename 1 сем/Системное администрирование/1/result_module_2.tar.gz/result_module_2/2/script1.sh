#!/bin/bash

# Список хостов для проверки
hosts=("192.168.1.0" "192.168.0.1" "skillbox.ru" "192.168.1.3")

available_count=0
unavailable_count=0

for host in "${hosts[@]}"; 
	do
# Пинг 1 пакета с таймаутом 1. Вывод ping - "выкидывается"
		if ping -c 1 -W 1 "$host" > /dev/null 2>&1; then
			echo "Хост $host доступен"
			((available_count++))
		else
			echo "Хост $host недоступен"
			((unavailable_count++))
		fi
done

# Вывод
echo "Всего доступно: $available_count"
echo "Всего недоступно: $unavailable_count"
