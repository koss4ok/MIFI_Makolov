#!/bin/bash

# Проверка на наличие аргументов
if [ "$#" -ne 1 ]; then
    echo "Использование: $0 <директория>"
    exit 1
fi

# Задание переменных
directory="$1"
keyword="ERROR"
total_count=0

# Поиск всех .log файлов и подсчет строк с ключевым словом
for file in "$directory"/*.log; do
    if [ -f "$file" ]; then
        count=$(grep -c "$keyword" "$file")
        echo "Файл $file содержит $count строк с ключевым словом $keyword"
        total_count=$((total_count + count))
    fi
done

# Вывод общего количества строк с ключевым словом
echo "Общее количество строк с ключевым словом '$keyword' по всем лог-файлам: $total_count"

